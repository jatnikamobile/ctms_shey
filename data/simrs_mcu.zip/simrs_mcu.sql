-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 21, 2019 at 02:00 PM
-- Server version: 5.7.24-0ubuntu0.18.04.1
-- PHP Version: 7.1.25-1+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simrs_mcu`
--

-- --------------------------------------------------------

--
-- Table structure for table `agama`
--

CREATE TABLE `agama` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agama`
--

INSERT INTO `agama` (`id`, `nama`) VALUES
(1, 'Islam'),
(2, 'Katolik'),
(3, 'Hindu'),
(4, 'Kristen'),
(5, 'Budha'),
(6, 'Konghuchu'),
(7, 'Lain-Lain');

-- --------------------------------------------------------

--
-- Table structure for table `diagnosa_kerja`
--

CREATE TABLE `diagnosa_kerja` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `diagnosa_kerja`
--

INSERT INTO `diagnosa_kerja` (`id`, `nama`) VALUES
(1, 'Fit On Job'),
(2, 'Temporary Unit'),
(3, 'Fit With Restiction'),
(4, 'Unfit'),
(5, 'Sehat'),
(6, 'Tidak Sehat');

-- --------------------------------------------------------

--
-- Table structure for table `dokter`
--

CREATE TABLE `dokter` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dokter`
--

INSERT INTO `dokter` (`id`, `nama`) VALUES
(6, 'Dr.Dokter');

-- --------------------------------------------------------

--
-- Table structure for table `instansi`
--

CREATE TABLE `instansi` (
  `id` int(11) NOT NULL,
  `kode` varchar(4) DEFAULT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `instansi`
--

INSERT INTO `instansi` (`id`, `kode`, `nama`) VALUES
(3, '1111', 'Instansi Pengembangan'),
(4, '0618', 'RSAU ESNAWAN ANTARIKSA'),
(8, 'tes', 'tes instansi');

-- --------------------------------------------------------

--
-- Table structure for table `kesimpulan`
--

CREATE TABLE `kesimpulan` (
  `id` int(11) NOT NULL,
  `id_registrasi` int(11) NOT NULL,
  `id_diagnosa_kerja` int(11) DEFAULT NULL,
  `isi_kesimpulan` varchar(255) DEFAULT NULL,
  `saran` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kesimpulan`
--

INSERT INTO `kesimpulan` (`id`, `id_registrasi`, `id_diagnosa_kerja`, `isi_kesimpulan`, `saran`) VALUES
(2, 35, NULL, 'Scrotalis : Negativ, ', NULL),
(3, 1, NULL, 'RIWAYAT KESEHATAN KELUARGA : Ada, ', NULL),
(4, 2, NULL, '', NULL),
(5, 3, NULL, NULL, NULL),
(6, 4, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `kop`
--

CREATE TABLE `kop` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `telp` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kop`
--

INSERT INTO `kop` (`id`, `nama`, `alamat`, `telp`, `email`, `website`, `photo`) VALUES
(1, 'RSAU dr. Esnawan Antariksa', 'Jalan Merpati No.2 Halim Perdana Kusuma Jakarta Timur', '02180882817', 'itrsauantariska@gmail.com', 'www.rsauesnawan.com', 'logo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `laboratorium`
--

CREATE TABLE `laboratorium` (
  `id` int(11) NOT NULL,
  `id_registrasi` int(11) NOT NULL,
  `hasil_pemeriksaan` varchar(255) DEFAULT 'Normal',
  `berkas_lab` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `laboratorium`
--

INSERT INTO `laboratorium` (`id`, `id_registrasi`, `hasil_pemeriksaan`, `berkas_lab`) VALUES
(3, 35, 'Normal', NULL),
(4, 1, 'Normal', NULL),
(5, 1, 'Normal', NULL),
(6, 2, 'Normal', NULL),
(7, 2, 'Normal', NULL),
(8, 3, 'Normal', NULL),
(9, 3, 'Normal', NULL),
(10, 4, 'Normal', NULL),
(11, 4, 'Normal', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `laboratorium_hematologi`
--

CREATE TABLE `laboratorium_hematologi` (
  `id` int(11) NOT NULL,
  `id_laboratorium` int(11) NOT NULL,
  `hemoglobin` varchar(255) DEFAULT NULL,
  `lekosit` varchar(255) DEFAULT NULL,
  `hematokrit` varchar(255) DEFAULT NULL,
  `trombosit` varchar(255) DEFAULT NULL,
  `eritrosit` varchar(255) DEFAULT NULL,
  `hj_basofil` varchar(255) DEFAULT NULL,
  `hj_eosinofil` varchar(255) DEFAULT NULL,
  `hj_neutrofil_batang` varchar(255) DEFAULT NULL,
  `hj_neutrofil_segment` varchar(255) DEFAULT NULL,
  `hj_limfosit` varchar(255) DEFAULT NULL,
  `hj_monosit` varchar(255) DEFAULT NULL,
  `led` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `laboratorium_hematologi`
--

INSERT INTO `laboratorium_hematologi` (`id`, `id_laboratorium`, `hemoglobin`, `lekosit`, `hematokrit`, `trombosit`, `eritrosit`, `hj_basofil`, `hj_eosinofil`, `hj_neutrofil_batang`, `hj_neutrofil_segment`, `hj_limfosit`, `hj_monosit`, `led`) VALUES
(1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `laboratorium_imunoserologi`
--

CREATE TABLE `laboratorium_imunoserologi` (
  `id` int(11) NOT NULL,
  `id_laboratorium` int(11) NOT NULL,
  `hbs_ag` varchar(255) DEFAULT 'Non Reaktif'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `laboratorium_imunoserologi`
--

INSERT INTO `laboratorium_imunoserologi` (`id`, `id_laboratorium`, `hbs_ag`) VALUES
(1, 2, 'Non Reaktif'),
(2, 1, 'Non Reaktif'),
(3, 4, 'Non Reaktif'),
(4, 3, 'Non Reaktif'),
(5, 5, 'Non Reaktif'),
(6, 7, 'Non Reaktif'),
(7, 9, 'Non Reaktif'),
(8, 11, 'Non Reaktif'),
(9, 10, 'Non Reaktif'),
(10, 6, 'Non Reaktif');

-- --------------------------------------------------------

--
-- Table structure for table `laboratorium_kimia`
--

CREATE TABLE `laboratorium_kimia` (
  `id` int(11) NOT NULL,
  `id_laboratorium` int(11) NOT NULL,
  `faal_hati_sgot` varchar(255) DEFAULT NULL,
  `faal_hati_sgpt` varchar(255) DEFAULT NULL,
  `lemak_kolesterol_total` varchar(255) DEFAULT NULL,
  `lemak_trigliserida` varchar(255) DEFAULT NULL,
  `lemak_kolesterol_hdl` varchar(255) DEFAULT NULL,
  `lemak_kolesterol_ldl` varchar(255) DEFAULT NULL,
  `diabetes_glukosa_puasa` varchar(255) DEFAULT NULL,
  `diabetes_glukosa_2_jam` varchar(255) DEFAULT NULL,
  `diabetes_gamma_gt` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `laboratorium_kimia`
--

INSERT INTO `laboratorium_kimia` (`id`, `id_laboratorium`, `faal_hati_sgot`, `faal_hati_sgpt`, `lemak_kolesterol_total`, `lemak_trigliserida`, `lemak_kolesterol_hdl`, `lemak_kolesterol_ldl`, `diabetes_glukosa_puasa`, `diabetes_glukosa_2_jam`, `diabetes_gamma_gt`) VALUES
(1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `laboratorium_narkoba`
--

CREATE TABLE `laboratorium_narkoba` (
  `id` int(11) NOT NULL,
  `id_laboratorium` int(11) NOT NULL,
  `methamphetamine` varchar(255) DEFAULT 'Negatif',
  `cocain` varchar(255) DEFAULT 'Negatif',
  `amphetamine` varchar(255) DEFAULT 'Negatif',
  `morphine` varchar(255) DEFAULT 'Negatif',
  `mariyuana` varchar(255) DEFAULT 'Negatif'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `laboratorium_narkoba`
--

INSERT INTO `laboratorium_narkoba` (`id`, `id_laboratorium`, `methamphetamine`, `cocain`, `amphetamine`, `morphine`, `mariyuana`) VALUES
(1, 2, 'Negatif', 'Negatif', 'Negatif', 'Negatif', 'Negatif'),
(2, 1, 'Negatif', 'Negatif', 'Negatif', 'Negatif', 'Negatif'),
(3, 4, 'Negatif', 'Negatif', 'Negatif', 'Negatif', 'Negatif'),
(4, 3, 'Negatif', 'Negatif', 'Negatif', 'Negatif', 'Negatif'),
(5, 5, 'Negatif', 'Negatif', 'Negatif', 'Negatif', 'Negatif'),
(6, 7, 'Negatif', 'Negatif', 'Negatif', 'Negatif', 'Negatif'),
(7, 9, 'Negatif', 'Negatif', 'Negatif', 'Negatif', 'Negatif'),
(8, 11, 'Negatif', 'Negatif', 'Negatif', 'Negatif', 'Negatif'),
(9, 10, 'Negatif', 'Negatif', 'Negatif', 'Negatif', 'Negatif'),
(10, 6, 'Negatif', 'Negatif', 'Negatif', 'Negatif', 'Negatif');

-- --------------------------------------------------------

--
-- Table structure for table `laboratorium_urinalisa`
--

CREATE TABLE `laboratorium_urinalisa` (
  `id` int(11) NOT NULL,
  `id_laboratorium` int(11) NOT NULL,
  `ph` varchar(255) DEFAULT NULL,
  `berat_jenis` varchar(255) DEFAULT NULL,
  `protein` varchar(255) DEFAULT 'Negatif',
  `reduksi` varchar(255) DEFAULT 'Negatif',
  `bilirubin` varchar(255) DEFAULT 'Negatif',
  `urobilinogen` varchar(255) DEFAULT 'Positif',
  `nitrit` varchar(255) DEFAULT 'Negatif',
  `keton` varchar(255) DEFAULT 'Negatif',
  `darah` varchar(255) DEFAULT 'Negatif',
  `mk_leukosit` varchar(255) DEFAULT NULL,
  `mk_eritrosit` varchar(255) DEFAULT NULL,
  `mk_silender` varchar(255) DEFAULT 'Negatif',
  `mk_epithel` varchar(255) DEFAULT 'Positif',
  `mk_kristal` varchar(255) DEFAULT 'Negatif',
  `mk_lainlain` varchar(255) DEFAULT 'Negatif'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `laboratorium_urinalisa`
--

INSERT INTO `laboratorium_urinalisa` (`id`, `id_laboratorium`, `ph`, `berat_jenis`, `protein`, `reduksi`, `bilirubin`, `urobilinogen`, `nitrit`, `keton`, `darah`, `mk_leukosit`, `mk_eritrosit`, `mk_silender`, `mk_epithel`, `mk_kristal`, `mk_lainlain`) VALUES
(1, 2, '5', '1000', 'Negatif', 'Negatif', 'Negatif', 'Positif', 'Negatif', 'Negatif', 'Negatif', NULL, NULL, 'Negatif', 'Positif', 'Negatif', 'Negatif'),
(2, 1, '5', '1000', 'Negatif', 'Negatif', 'Negatif', 'Positif', 'Negatif', 'Negatif', 'Negatif', NULL, NULL, 'Negatif', 'Positif', 'Negatif', 'Negatif'),
(3, 4, '5', '1000', 'Negatif', 'Negatif', 'Negatif', 'Positif', 'Negatif', 'Negatif', 'Negatif', NULL, NULL, 'Negatif', 'Positif', 'Negatif', 'Negatif'),
(4, 3, '5', '1000', 'Negatif', 'Negatif', 'Negatif', 'Positif', 'Negatif', 'Negatif', 'Negatif', NULL, NULL, 'Negatif', 'Positif', 'Negatif', 'Negatif'),
(5, 5, NULL, NULL, 'Negatif', 'Negatif', 'Negatif', 'Positif', 'Negatif', 'Negatif', 'Negatif', NULL, NULL, 'Negatif', 'Positif', 'Negatif', 'Negatif'),
(6, 7, NULL, NULL, 'Negatif', 'Negatif', 'Negatif', 'Positif', 'Negatif', 'Negatif', 'Negatif', NULL, NULL, 'Negatif', 'Positif', 'Negatif', 'Negatif'),
(7, 9, NULL, NULL, 'Negatif', 'Negatif', 'Negatif', 'Positif', 'Negatif', 'Negatif', 'Negatif', NULL, NULL, 'Negatif', 'Positif', 'Negatif', 'Negatif'),
(8, 11, NULL, NULL, 'Negatif', 'Negatif', 'Negatif', 'Positif', 'Negatif', 'Negatif', 'Negatif', NULL, NULL, 'Negatif', 'Positif', 'Negatif', 'Negatif'),
(9, 10, NULL, NULL, 'Negatif', 'Negatif', 'Negatif', 'Positif', 'Negatif', 'Negatif', 'Negatif', NULL, NULL, 'Negatif', 'Positif', 'Negatif', 'Negatif'),
(10, 6, NULL, NULL, 'Negatif', 'Negatif', 'Negatif', 'Positif', 'Negatif', 'Negatif', 'Negatif', NULL, NULL, 'Negatif', 'Positif', 'Negatif', 'Negatif');

-- --------------------------------------------------------

--
-- Table structure for table `paket`
--

CREATE TABLE `paket` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paket`
--

INSERT INTO `paket` (`id`, `nama`) VALUES
(1, 'Paket A'),
(2, 'Paket B'),
(3, 'Paket C');

-- --------------------------------------------------------

--
-- Table structure for table `paket_pemeriksaan`
--

CREATE TABLE `paket_pemeriksaan` (
  `id` int(11) NOT NULL,
  `id_paket` int(11) NOT NULL,
  `id_pemeriksaan` int(11) NOT NULL,
  `status_kesimpulan` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paket_pemeriksaan`
--

INSERT INTO `paket_pemeriksaan` (`id`, `id_paket`, `id_pemeriksaan`, `status_kesimpulan`) VALUES
(1, 1, 1, 0),
(2, 1, 2, 1),
(3, 1, 3, 1),
(4, 1, 4, 1),
(5, 1, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `paket_tindakan`
--

CREATE TABLE `paket_tindakan` (
  `id` int(11) NOT NULL,
  `id_paket` int(11) DEFAULT NULL,
  `id_tindakan` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paket_tindakan`
--

INSERT INTO `paket_tindakan` (`id`, `id_paket`, `id_tindakan`) VALUES
(1, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `pasien`
--

CREATE TABLE `pasien` (
  `id` int(11) NOT NULL,
  `id_pasien_instansi` int(11) DEFAULT NULL,
  `id_pasien_unit` int(11) DEFAULT NULL,
  `nik` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` text,
  `tempat_lahir` varchar(255) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `umur` int(11) DEFAULT NULL,
  `jenis_kelamin` varchar(10) DEFAULT NULL,
  `golongan_darah` varchar(10) DEFAULT NULL,
  `no_telepon` varchar(20) DEFAULT NULL,
  `status_kawin` varchar(255) DEFAULT NULL,
  `id_pasien_agama` varchar(11) DEFAULT NULL,
  `id_pasien_pekerjaan` varchar(11) DEFAULT NULL,
  `id_pasien_pendidikan` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pasien`
--

INSERT INTO `pasien` (`id`, `id_pasien_instansi`, `id_pasien_unit`, `nik`, `nama`, `alamat`, `tempat_lahir`, `tanggal_lahir`, `umur`, `jenis_kelamin`, `golongan_darah`, `no_telepon`, `status_kawin`, `id_pasien_agama`, `id_pasien_pekerjaan`, `id_pasien_pendidikan`) VALUES
(1, 3, 3, '1998097097', 'Muhammad Fauzan Noor Azhar', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Jakarta', '2017-11-01', 0, 'Laki-Laki', 'B', '08917097301', 'kawin', NULL, NULL, NULL),
(2, 3, 3, '1987817389', 'Dadan Satria', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Jakarta', '2018-01-10', NULL, 'Laki-Laki', 'B', '080930917097', 'kawin', NULL, NULL, NULL),
(3, 3, 3, '98970970', 'Iqbal', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Lorem Ipusm', '2019-01-13', NULL, 'Perempuan', 'A', '98096896', 'kawin', NULL, NULL, NULL),
(4, 4, 4, '098765432123', 'MUHAMMAD', 'BANDUNG', 'BANDUNG', '1992-12-31', 27, 'Laki-Laki', 'O', '087819213112', 'belum kawin', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pekerjaan`
--

CREATE TABLE `pekerjaan` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan`
--

CREATE TABLE `pemeriksaan` (
  `id` int(11) NOT NULL,
  `id_induk` int(11) DEFAULT NULL,
  `nama` varchar(255) NOT NULL,
  `status_bmi` int(11) DEFAULT NULL,
  `status_tekanan_darah` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan`
--

INSERT INTO `pemeriksaan` (`id`, `id_induk`, `nama`, `status_bmi`, `status_tekanan_darah`) VALUES
(1, NULL, 'Pemeriksaan Fisik', NULL, NULL),
(2, NULL, 'Laboratorium', NULL, NULL),
(3, NULL, 'Radiologi', NULL, NULL),
(4, NULL, 'Spirometri', NULL, NULL),
(5, NULL, 'Audiometri', NULL, NULL),
(6, NULL, 'EKG', NULL, NULL),
(7, NULL, 'Treadmill', NULL, NULL),
(8, NULL, 'USG', NULL, NULL),
(9, 1, 'Mata', NULL, NULL),
(10, 1, 'Telinga', NULL, NULL),
(11, 1, 'Timpani', NULL, NULL),
(12, 1, 'Hidung', NULL, NULL),
(13, 1, 'Leher', NULL, NULL),
(14, 1, 'Mulut', NULL, NULL),
(15, 1, 'Thorax', NULL, NULL),
(16, 1, 'Abdomen', NULL, NULL),
(17, 1, 'Manufer Ekstremitas', NULL, NULL),
(22, 2, 'Hematologi', NULL, NULL),
(23, 2, 'Imunoserologi', NULL, NULL),
(24, 2, 'Kimia', NULL, NULL),
(26, 2, 'Urinalisa', NULL, NULL),
(27, 2, 'Narkoba', NULL, NULL),
(28, 1, 'BMI', 1, NULL),
(29, 1, 'Tekanan Darah', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_audiometry`
--

CREATE TABLE `pemeriksaan_audiometry` (
  `id` int(11) NOT NULL,
  `id_registrasi` int(11) NOT NULL,
  `l1000` int(11) DEFAULT NULL,
  `l4000` int(11) DEFAULT NULL,
  `r1000` int(11) DEFAULT NULL,
  `r4000` int(11) DEFAULT NULL,
  `selisih` int(11) DEFAULT NULL,
  `nih` varchar(255) DEFAULT NULL,
  `uraian` varchar(255) DEFAULT NULL,
  `kesimpulan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_audiometry`
--

INSERT INTO `pemeriksaan_audiometry` (`id`, `id_registrasi`, `l1000`, `l4000`, `r1000`, `r4000`, `selisih`, `nih`, `uraian`, `kesimpulan`) VALUES
(2, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_ekg`
--

CREATE TABLE `pemeriksaan_ekg` (
  `id` int(11) NOT NULL,
  `id_registrasi` int(11) NOT NULL,
  `hasil` varchar(255) DEFAULT NULL,
  `kesan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_ekg`
--

INSERT INTO `pemeriksaan_ekg` (`id`, `id_registrasi`, `hasil`, `kesan`) VALUES
(2, 35, NULL, NULL),
(3, 1, '', ''),
(4, 2, NULL, NULL),
(5, 3, NULL, NULL),
(6, 4, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_fisik`
--

CREATE TABLE `pemeriksaan_fisik` (
  `id` int(11) NOT NULL,
  `id_registrasi` int(11) NOT NULL,
  `keluhan_utama` varchar(255) DEFAULT 'Tidak Ada',
  `riwayat_alergi` varchar(255) DEFAULT 'Tidak Ada',
  `riwayat_kesehatan_dulu` varchar(255) DEFAULT 'Tidak Ada',
  `riwayat_kesehatan_keluarga` varchar(255) DEFAULT 'Tidak Ada',
  `kebiasaan` varchar(255) DEFAULT 'Tidak Ada',
  `sistolik` int(11) DEFAULT NULL,
  `diastolik` int(11) DEFAULT NULL,
  `tinggi_badan` int(11) DEFAULT NULL,
  `berat_badan` int(11) DEFAULT NULL,
  `golongan_darah` varchar(255) DEFAULT NULL,
  `buta_warna` varchar(255) DEFAULT NULL,
  `anamnesa` varchar(255) DEFAULT NULL,
  `nadi` varchar(255) DEFAULT NULL,
  `pernafasan` varchar(255) DEFAULT NULL,
  `suhu` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_fisik`
--

INSERT INTO `pemeriksaan_fisik` (`id`, `id_registrasi`, `keluhan_utama`, `riwayat_alergi`, `riwayat_kesehatan_dulu`, `riwayat_kesehatan_keluarga`, `kebiasaan`, `sistolik`, `diastolik`, `tinggi_badan`, `berat_badan`, `golongan_darah`, `buta_warna`, `anamnesa`, `nadi`, `pernafasan`, `suhu`) VALUES
(3, 35, 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', NULL, NULL, NULL, NULL, '', '', '', '', '', ''),
(4, 1, 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 100, 97, 150, 10, '', '', '', '', '', ''),
(5, 1, 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 2, 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 2, 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 3, 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 3, 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 4, 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 4, 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', 'Tidak Ada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_fisik_abdomen`
--

CREATE TABLE `pemeriksaan_fisik_abdomen` (
  `id` int(11) NOT NULL,
  `id_pemeriksaan_fisik` int(11) NOT NULL,
  `dinding` varchar(255) DEFAULT 'Normal',
  `hati` varchar(255) DEFAULT 'Normal',
  `limpa` varchar(255) DEFAULT 'Normal',
  `usus` varchar(255) DEFAULT 'Normal',
  `hernia` varchar(255) DEFAULT 'Normal',
  `scrotalis` varchar(255) DEFAULT 'Negativ'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_fisik_abdomen`
--

INSERT INTO `pemeriksaan_fisik_abdomen` (`id`, `id_pemeriksaan_fisik`, `dinding`, `hati`, `limpa`, `usus`, `hernia`, `scrotalis`) VALUES
(1, 2, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Negativ'),
(2, 1, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Negativ'),
(3, 4, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Negativ'),
(4, 3, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Negativ'),
(5, 5, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Negativ'),
(6, 7, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Negativ'),
(7, 9, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Negativ'),
(8, 11, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Negativ'),
(9, 10, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Negativ'),
(10, 6, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Negativ');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_fisik_hidung`
--

CREATE TABLE `pemeriksaan_fisik_hidung` (
  `id` int(11) NOT NULL,
  `id_pemeriksaan_fisik` int(11) NOT NULL,
  `bentuk_hidung` varchar(255) DEFAULT 'Normal',
  `septum_deviasi` varchar(255) DEFAULT 'Tidak Ada',
  `conchae` varchar(255) DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_fisik_hidung`
--

INSERT INTO `pemeriksaan_fisik_hidung` (`id`, `id_pemeriksaan_fisik`, `bentuk_hidung`, `septum_deviasi`, `conchae`) VALUES
(1, 2, 'Normal', 'Tidak Ada', 'Normal'),
(2, 1, 'Normal', 'Tidak Ada', 'Normal'),
(3, 4, 'Normal', 'Tidak Ada', 'Normal'),
(4, 3, 'Normal', 'Tidak Ada', 'Normal'),
(5, 5, 'Normal', 'Tidak Ada', 'Normal'),
(6, 7, 'Normal', 'Tidak Ada', 'Normal'),
(7, 9, 'Normal', 'Tidak Ada', 'Normal'),
(8, 11, 'Normal', 'Tidak Ada', 'Normal'),
(9, 10, 'Normal', 'Tidak Ada', 'Normal'),
(10, 6, 'Normal', 'Tidak Ada', 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_fisik_leher`
--

CREATE TABLE `pemeriksaan_fisik_leher` (
  `id` int(11) NOT NULL,
  `id_pemeriksaan_fisik` int(11) NOT NULL,
  `tiroid` varchar(255) DEFAULT 'Tidak Teraba',
  `limfonoid` varchar(255) DEFAULT 'Tidak Teraba',
  `tenggorokan` varchar(255) DEFAULT 'Normal',
  `tonsil` varchar(255) DEFAULT 'Normal',
  `faring` varchar(255) DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_fisik_leher`
--

INSERT INTO `pemeriksaan_fisik_leher` (`id`, `id_pemeriksaan_fisik`, `tiroid`, `limfonoid`, `tenggorokan`, `tonsil`, `faring`) VALUES
(1, 2, 'Tidak Teraba', 'Tidak Teraba', 'Normal', 'Normal', 'Normal'),
(2, 1, 'Tidak Teraba', 'Tidak Teraba', 'Normal', 'Normal', 'Normal'),
(3, 4, 'Tidak Teraba', 'Tidak Teraba', 'Normal', 'Normal', 'Normal'),
(4, 3, 'Tidak Teraba', 'Tidak Teraba', 'Normal', 'Normal', 'Normal'),
(5, 5, 'Tidak Teraba', 'Tidak Teraba', 'Normal', 'Normal', 'Normal'),
(6, 7, 'Tidak Teraba', 'Tidak Teraba', 'Normal', 'Normal', 'Normal'),
(7, 9, 'Tidak Teraba', 'Tidak Teraba', 'Normal', 'Normal', 'Normal'),
(8, 11, 'Tidak Teraba', 'Tidak Teraba', 'Normal', 'Normal', 'Normal'),
(9, 10, 'Tidak Teraba', 'Tidak Teraba', 'Normal', 'Normal', 'Normal'),
(10, 6, 'Tidak Teraba', 'Tidak Teraba', 'Normal', 'Normal', 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_fisik_manufer_ekstremitas`
--

CREATE TABLE `pemeriksaan_fisik_manufer_ekstremitas` (
  `id` int(11) NOT NULL,
  `id_pemeriksaan_fisik` int(11) NOT NULL,
  `kekuatan` varchar(255) DEFAULT 'Normal',
  `varises` varchar(255) DEFAULT 'Normal',
  `reflek_fisiologis` varchar(255) DEFAULT 'Normal',
  `reflek_patologis` varchar(255) DEFAULT 'Normal',
  `lainlain` varchar(255) DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_fisik_manufer_ekstremitas`
--

INSERT INTO `pemeriksaan_fisik_manufer_ekstremitas` (`id`, `id_pemeriksaan_fisik`, `kekuatan`, `varises`, `reflek_fisiologis`, `reflek_patologis`, `lainlain`) VALUES
(1, 2, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal'),
(2, 1, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal'),
(3, 4, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal'),
(4, 3, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal'),
(5, 5, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal'),
(6, 7, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal'),
(7, 9, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal'),
(8, 11, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal'),
(9, 10, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal'),
(10, 6, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_fisik_mata`
--

CREATE TABLE `pemeriksaan_fisik_mata` (
  `id` int(11) NOT NULL,
  `id_pemeriksaan_fisik` int(11) NOT NULL,
  `kacamata` varchar(255) DEFAULT 'Tidak Pakai',
  `kelopak_mata` varchar(255) DEFAULT 'Normal',
  `konjungtiva` varchar(255) DEFAULT 'Normal',
  `sklera` varchar(255) DEFAULT 'Normal',
  `pupil` varchar(255) DEFAULT 'Isokor',
  `buta_warna` varchar(255) DEFAULT 'Normal',
  `refraksi` varchar(255) DEFAULT 'Normal',
  `addisi` varchar(255) DEFAULT 'Normal',
  `funduskopi` varchar(255) DEFAULT 'Normal',
  `tekanan_bola` varchar(255) DEFAULT 'Normal',
  `mata_juling` varchar(255) DEFAULT 'Normal',
  `tonometri` varchar(255) DEFAULT '8/7.5 (ODS)'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_fisik_mata`
--

INSERT INTO `pemeriksaan_fisik_mata` (`id`, `id_pemeriksaan_fisik`, `kacamata`, `kelopak_mata`, `konjungtiva`, `sklera`, `pupil`, `buta_warna`, `refraksi`, `addisi`, `funduskopi`, `tekanan_bola`, `mata_juling`, `tonometri`) VALUES
(1, 2, 'Tidak Pakai', 'Normal', 'Normal', 'Normal', 'Isokor', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', '8/7.5 (ODS)'),
(2, 1, 'Pakai', 'Normal', 'Normal', 'Normal', 'Isokor', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', '8/7.5 (ODS)'),
(3, 4, 'Tidak Pakai', 'Hordeolum', 'Lain-lain', 'Normal', 'Isokor', 'Total', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', '8/7.5 (ODS)'),
(4, 3, 'Tidak Pakai', 'Normal', 'Normal', 'Normal', 'Isokor', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', '8/7.5 (ODS)'),
(5, 5, 'Tidak Pakai', 'Normal', 'Normal', 'Normal', 'Isokor', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', '8/7.5 (ODS)'),
(6, 7, 'Tidak Pakai', 'Normal', 'Normal', 'Normal', 'Isokor', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', '8/7.5 (ODS)'),
(7, 9, 'Tidak Pakai', 'Normal', 'Normal', 'Normal', 'Isokor', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', '8/7.5 (ODS)'),
(8, 11, 'Tidak Pakai', 'Normal', 'Normal', 'Normal', 'Isokor', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', '8/7.5 (ODS)'),
(9, 10, 'Tidak Pakai', 'Normal', 'Normal', 'Normal', 'Isokor', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', '8/7.5 (ODS)'),
(10, 6, 'Tidak Pakai', 'Normal', 'Normal', 'Normal', 'Isokor', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', '8/7.5 (ODS)');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_fisik_mulut`
--

CREATE TABLE `pemeriksaan_fisik_mulut` (
  `id` int(11) NOT NULL,
  `id_pemeriksaan_fisik` int(11) NOT NULL,
  `mucosa_mulut` varchar(255) DEFAULT 'Normal',
  `kelainan_gigi` varchar(255) DEFAULT 'Tidak ada Kelainan',
  `lidah` varchar(255) DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_fisik_mulut`
--

INSERT INTO `pemeriksaan_fisik_mulut` (`id`, `id_pemeriksaan_fisik`, `mucosa_mulut`, `kelainan_gigi`, `lidah`) VALUES
(1, 2, 'Normal', 'Tidak ada Kelainan', 'Normal'),
(2, 1, 'Normal', 'Tidak ada Kelainan', 'Normal'),
(3, 4, 'Normal', 'Tidak ada Kelainan', 'Normal'),
(4, 3, 'Normal', 'Tidak ada Kelainan', 'Normal'),
(5, 5, 'Normal', 'Tidak ada Kelainan', 'Normal'),
(6, 7, 'Normal', 'Tidak ada Kelainan', 'Normal'),
(7, 9, 'Normal', 'Tidak ada Kelainan', 'Normal'),
(8, 11, 'Normal', 'Tidak ada Kelainan', 'Normal'),
(9, 10, 'Normal', 'Tidak ada Kelainan', 'Normal'),
(10, 6, 'Normal', 'Tidak ada Kelainan', 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_fisik_telinga`
--

CREATE TABLE `pemeriksaan_fisik_telinga` (
  `id` int(11) NOT NULL,
  `id_pemeriksaan_fisik` int(11) NOT NULL,
  `bentuk_telinga` varchar(255) DEFAULT 'Normal',
  `membrane` varchar(255) DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_fisik_telinga`
--

INSERT INTO `pemeriksaan_fisik_telinga` (`id`, `id_pemeriksaan_fisik`, `bentuk_telinga`, `membrane`) VALUES
(1, 2, 'Normal', 'Normal'),
(2, 1, 'Normal', 'Normal'),
(3, 4, 'Normal', 'Normal'),
(4, 3, 'Normal', 'Normal'),
(5, 5, 'Normal', 'Normal'),
(6, 7, 'Normal', 'Normal'),
(7, 9, 'Normal', 'Normal'),
(8, 11, 'Normal', 'Normal'),
(9, 10, 'Normal', 'Normal'),
(10, 6, 'Normal', 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_fisik_thorax`
--

CREATE TABLE `pemeriksaan_fisik_thorax` (
  `id` int(11) NOT NULL,
  `id_pemeriksaan_fisik` int(11) NOT NULL,
  `dinding` varchar(255) DEFAULT 'Simetris',
  `paru_paru` varchar(255) DEFAULT 'Vesikuler',
  `jantung` varchar(255) DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_fisik_thorax`
--

INSERT INTO `pemeriksaan_fisik_thorax` (`id`, `id_pemeriksaan_fisik`, `dinding`, `paru_paru`, `jantung`) VALUES
(1, 2, 'Simetris', 'Vesikuler', 'Normal'),
(2, 1, 'Simetris', 'Vesikuler', 'Normal'),
(3, 4, 'Simetris', 'Vesikuler', 'Normal'),
(4, 3, 'Simetris', 'Vesikuler', 'Normal'),
(5, 5, 'Simetris', 'Vesikuler', 'Normal'),
(6, 7, 'Simetris', 'Vesikuler', 'Normal'),
(7, 9, 'Simetris', 'Vesikuler', 'Normal'),
(8, 11, 'Simetris', 'Vesikuler', 'Normal'),
(9, 10, 'Simetris', 'Vesikuler', 'Normal'),
(10, 6, 'Simetris', 'Vesikuler', 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_fisik_timpani`
--

CREATE TABLE `pemeriksaan_fisik_timpani` (
  `id` int(11) NOT NULL,
  `id_pemeriksaan_fisik` int(11) NOT NULL,
  `serumen` varchar(255) DEFAULT '-/-',
  `lainlain` varchar(255) DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_fisik_timpani`
--

INSERT INTO `pemeriksaan_fisik_timpani` (`id`, `id_pemeriksaan_fisik`, `serumen`, `lainlain`) VALUES
(1, 2, '-/-', 'Normal'),
(2, 1, '-/-', 'Normal'),
(3, 4, '-/-', 'Normal'),
(4, 3, '-/-', 'Normal'),
(5, 5, '-/-', 'Normal'),
(6, 7, '-/-', 'Normal'),
(7, 9, '-/-', 'Normal'),
(8, 11, '-/-', 'Normal'),
(9, 10, '-/-', 'Normal'),
(10, 6, '-/-', 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_rincian`
--

CREATE TABLE `pemeriksaan_rincian` (
  `id` int(11) NOT NULL,
  `id_pemeriksaan` int(11) NOT NULL,
  `id_induk` int(11) DEFAULT NULL,
  `nama` varchar(255) NOT NULL,
  `append` varchar(255) DEFAULT NULL,
  `rincian_jenis` int(11) NOT NULL DEFAULT '1',
  `default_value` varchar(255) DEFAULT NULL,
  `nilai_rujukan` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_rincian`
--

INSERT INTO `pemeriksaan_rincian` (`id`, `id_pemeriksaan`, `id_induk`, `nama`, `append`, `rincian_jenis`, `default_value`, `nilai_rujukan`) VALUES
(1, 1, NULL, 'KELUHAN UTAMA', NULL, 2, 'Tidak Ada', NULL),
(2, 1, NULL, 'RIWAYAT ALERGI', NULL, 2, 'Tidak Ada', NULL),
(3, 1, NULL, 'RIWAYAT KESEHATAN DULU', NULL, 2, 'Tidak Ada', NULL),
(4, 1, NULL, 'RIWAYAT KESEHATAN KELUARGA', NULL, 2, 'Tidak Ada', NULL),
(5, 1, NULL, 'KEBIASAAN', NULL, 2, 'Tidak Ada', NULL),
(14, 9, NULL, 'KACAMATA', NULL, 1, NULL, NULL),
(18, 9, NULL, 'Kelopak Mata', NULL, 1, NULL, NULL),
(22, 9, NULL, 'Konjungtiva', NULL, 1, NULL, NULL),
(23, 9, NULL, 'Sklera', NULL, 1, NULL, NULL),
(24, 9, NULL, 'Pupil', NULL, 1, NULL, NULL),
(25, 9, NULL, 'Buta Warna', NULL, 1, NULL, NULL),
(26, 9, NULL, 'Refraksi', NULL, 1, NULL, NULL),
(27, 9, NULL, 'Addisi', NULL, 1, NULL, NULL),
(28, 9, NULL, 'Funduskopi', NULL, 1, NULL, NULL),
(29, 9, NULL, 'Tekanan Bola', NULL, 1, NULL, NULL),
(31, 9, NULL, 'Mata Juling', NULL, 1, NULL, NULL),
(32, 9, NULL, 'Tonometri', NULL, 1, NULL, NULL),
(33, 10, NULL, 'Bentuk Telinga', NULL, 1, NULL, NULL),
(34, 10, NULL, 'Membrane', NULL, 1, NULL, NULL),
(35, 11, NULL, 'Serumen', NULL, 1, NULL, NULL),
(36, 11, NULL, 'Lain - Lain', NULL, 1, NULL, NULL),
(37, 12, NULL, 'Bentuk Hidung', NULL, 1, NULL, NULL),
(38, 12, NULL, 'Septum Deviasi', NULL, 1, NULL, NULL),
(39, 12, NULL, 'Conchae', NULL, 1, NULL, NULL),
(40, 13, NULL, 'Tiroid', NULL, 1, NULL, NULL),
(41, 13, NULL, 'Limfonoid', NULL, 1, NULL, NULL),
(43, 13, NULL, 'Tenggorokan', NULL, 1, NULL, NULL),
(44, 13, NULL, 'Tonsil', NULL, 1, NULL, NULL),
(45, 13, NULL, 'Faring', NULL, 1, NULL, NULL),
(46, 14, NULL, 'Mucosa Mulut', NULL, 1, NULL, NULL),
(47, 14, NULL, 'Kelainan Gigi', NULL, 1, NULL, NULL),
(48, 14, NULL, 'Lidah', NULL, 1, NULL, NULL),
(49, 15, NULL, 'Dinding', NULL, 1, NULL, NULL),
(50, 15, NULL, 'Paru Paru', NULL, 1, NULL, NULL),
(51, 15, NULL, 'Jantung', NULL, 1, NULL, NULL),
(52, 16, NULL, 'Dinding', NULL, 1, NULL, NULL),
(53, 16, NULL, 'Hati', NULL, 1, NULL, NULL),
(54, 16, NULL, 'Limpa', NULL, 1, NULL, NULL),
(55, 16, NULL, 'Usus', NULL, 1, NULL, NULL),
(56, 16, NULL, 'Hernia', NULL, 1, NULL, NULL),
(57, 16, NULL, 'Scrotalis', NULL, 1, NULL, NULL),
(59, 17, NULL, 'Kekuatan', NULL, 1, NULL, NULL),
(60, 17, NULL, 'Varises', NULL, 1, NULL, NULL),
(61, 17, NULL, 'Reflek Fisiologis', NULL, 1, NULL, NULL),
(62, 17, NULL, 'Reflek Patologis', NULL, 1, NULL, NULL),
(63, 17, NULL, 'Lain - Lain', NULL, 1, NULL, NULL),
(64, 2, NULL, 'Hasil Pemeriksaan', NULL, 7, NULL, NULL),
(65, 22, 175, 'Hemoglobin', 'gr/dl', 2, NULL, 'P 13,2 - 17,3 W 11,7 - 15,5 gr/dl'),
(66, 22, 175, 'Lekosit', 'mm3', 2, NULL, 'P: 3800 - 10600 W: 3600 - 11000/mm3'),
(68, 22, 175, 'Hematokrit', '%', 2, NULL, 'P: 40 - 52% W: 35 - 47%'),
(69, 22, 175, 'Trombosit', 'mm3', 2, NULL, '150 - 440 ribu/mm3'),
(70, 22, 175, 'Eritrosit', 'mm3', 2, NULL, 'P: 4,5 - 5,5 juta/mm3 W: 4,0 - 5,2 juta/mm3'),
(71, 22, 175, 'LED', 'mm/jam', 2, NULL, 'P: < 15, W <20 mm/jam'),
(72, 22, 176, 'Basofil', '%', 2, NULL, '0 - 1%'),
(73, 22, 176, 'Eosinofil', '%', 2, NULL, '2 - 4%'),
(74, 22, 176, 'Neutrofil Batang', '%', 2, NULL, '3 - 5%'),
(75, 22, 176, 'Neutrofil Segment', '%', 2, NULL, '50 - 70%'),
(76, 22, 176, 'Limfosit', '%', 2, NULL, '25 - 40%'),
(77, 22, 176, 'Monosit', '%', 2, NULL, '2 - 8%'),
(78, 23, NULL, 'Hbs Ag', NULL, 1, NULL, NULL),
(79, 24, NULL, 'Faal Hati', NULL, 3, NULL, NULL),
(81, 24, NULL, 'Profil Lemak', 'mg/dL', 3, NULL, NULL),
(85, 24, 79, 'SGOT', 'u/l', 2, NULL, NULL),
(86, 24, 79, 'SGPT', 'u/l', 2, NULL, NULL),
(87, 24, 81, 'Kolesterol Total', 'mg/dL', 2, NULL, NULL),
(88, 24, 81, 'Trigliserida', 'mg/dL', 2, NULL, NULL),
(89, 24, 81, 'Kolesterol HDL', 'mg/dL', 2, NULL, NULL),
(90, 24, 81, 'Kolesterol LDL', 'mg/dL', 2, NULL, NULL),
(91, 24, NULL, 'Diabetes', NULL, 3, NULL, NULL),
(92, 24, 91, 'Glukosa Puasa', 'mg/dL', 2, NULL, NULL),
(93, 24, 91, 'Glukosa 2 Jam PP', 'mg/dL', 2, NULL, NULL),
(94, 24, 91, 'Gamma GT', 'u/l', 2, NULL, NULL),
(95, 26, NULL, 'Urin Lengkap', NULL, 3, NULL, NULL),
(96, 26, 95, 'PH', NULL, 2, NULL, NULL),
(97, 26, 95, 'Berat Jenis', NULL, 2, NULL, NULL),
(98, 26, 95, 'Protein', NULL, 2, 'Negatif', NULL),
(99, 26, 95, 'Reduksi', NULL, 2, 'Negatif', NULL),
(100, 26, 95, 'Bilirubin', NULL, 2, 'Negatif', NULL),
(101, 26, 95, 'Urobilinogen', NULL, 2, 'Positif', NULL),
(103, 26, 95, 'Nitrit', NULL, 2, 'Negatif', NULL),
(104, 26, 95, 'Keton', NULL, 2, 'Negatif', NULL),
(105, 26, 95, 'Darah', NULL, 2, 'Negatif', NULL),
(106, 26, 95, 'Mikroskopis', NULL, 3, NULL, NULL),
(107, 26, 106, 'Leukosit', '/LPB', 2, NULL, NULL),
(108, 26, 106, 'Eritrosit', '/LPB', 2, NULL, NULL),
(109, 26, 106, 'Silender', NULL, 2, 'Negatif', NULL),
(110, 26, 106, 'Ephitel', NULL, 2, 'Positif', NULL),
(111, 26, 106, 'Kristal', NULL, 2, 'Negatif', NULL),
(112, 26, 106, 'Lain - Lain', NULL, 2, 'Negatif', NULL),
(113, 27, NULL, 'Methamphetamine', NULL, 1, NULL, NULL),
(114, 27, NULL, 'Cocain', NULL, 1, NULL, NULL),
(115, 27, NULL, 'Amphetamine', NULL, 1, NULL, NULL),
(116, 27, NULL, 'Morphine', NULL, 1, NULL, NULL),
(117, 27, NULL, 'Mariyuana', NULL, 1, NULL, NULL),
(119, 3, NULL, 'COR', NULL, 2, 'Normal', NULL),
(120, 3, NULL, 'PULMO', NULL, 2, 'Normal', NULL),
(121, 3, NULL, 'Sinus & Diafragma', NULL, 2, 'Normal', NULL),
(122, 3, NULL, 'Tulang Dan Jaringan Lunak', NULL, 2, 'Normal', NULL),
(123, 3, NULL, 'Hasil Pemeriksaan', NULL, 2, 'Normal', NULL),
(124, 4, NULL, 'Hasil', NULL, 2, 'Normal', NULL),
(125, 4, NULL, 'Kesimpulan', NULL, 2, 'Normal', NULL),
(126, 5, NULL, 'L1000', NULL, 2, NULL, NULL),
(127, 5, NULL, 'L4000', NULL, 2, NULL, NULL),
(128, 5, NULL, 'R1000', NULL, 2, NULL, NULL),
(129, 5, NULL, 'R4000', NULL, 2, NULL, NULL),
(130, 5, NULL, 'Selisih', NULL, 2, NULL, NULL),
(131, 5, NULL, 'Nih', NULL, 2, NULL, NULL),
(132, 5, NULL, 'Uraian', NULL, 2, NULL, NULL),
(133, 5, NULL, 'Kesimpulan', NULL, 2, NULL, NULL),
(134, 6, NULL, 'Hasil', NULL, 2, NULL, NULL),
(135, 6, NULL, 'Kesan', NULL, 2, NULL, NULL),
(136, 8, NULL, 'Hati', NULL, 2, NULL, NULL),
(137, 8, NULL, 'K.G.B', NULL, 1, NULL, NULL),
(139, 8, NULL, 'Empedu', NULL, 2, NULL, NULL),
(140, 8, NULL, 'Limpa', NULL, 2, NULL, NULL),
(141, 8, NULL, 'Pankreas', NULL, 2, NULL, NULL),
(142, 8, NULL, 'Ginjal', NULL, 2, NULL, NULL),
(143, 8, NULL, 'Kemih', NULL, 2, NULL, NULL),
(144, 8, NULL, 'Lain - Lain', NULL, 2, NULL, NULL),
(145, 8, NULL, 'Kesimpulan', NULL, 2, 'Abnormal', NULL),
(146, 7, NULL, 'Metode', NULL, 2, NULL, NULL),
(147, 7, NULL, 'Jantung', NULL, 1, NULL, NULL),
(148, 7, NULL, 'Klasifikasi Fitness Poor', 'Mets', 2, NULL, NULL),
(149, 7, NULL, 'Klasifikasi Fitness Fair', 'Mets', 2, NULL, NULL),
(150, 7, NULL, 'Klasifikasi Fitness Average', 'Mets', 2, NULL, NULL),
(151, 7, NULL, 'Klasifikasi Fitness Good', 'Mets', 2, NULL, NULL),
(152, 7, NULL, 'Klasifikasi Fitness Excelent', 'Mets', 2, NULL, NULL),
(153, 7, NULL, 'Klasifikasi Fungsional 1', NULL, 2, NULL, NULL),
(154, 7, NULL, 'Klasifikasi Fungsional 2', NULL, 2, NULL, NULL),
(155, 7, NULL, 'Klasifikasi Fungsional 3', NULL, 2, NULL, NULL),
(156, 7, NULL, 'Stop Treadmill', NULL, 2, NULL, NULL),
(157, 7, NULL, 'Resume Hasil', NULL, 2, 'Abnormal', NULL),
(158, 7, NULL, 'Denyut Nadi Awal', NULL, 2, NULL, NULL),
(159, 7, NULL, 'Denyut Nadi Akhir', NULL, 2, NULL, NULL),
(160, 7, NULL, 'Tekanan Darah Awal', NULL, 3, NULL, NULL),
(163, 7, NULL, 'Tekanan Darah Akhir', NULL, 3, NULL, NULL),
(166, 7, NULL, 'MAX', 'HR', 2, NULL, NULL),
(167, 7, NULL, 'Submax', 'HR', 2, NULL, NULL),
(168, 28, NULL, 'Tinggi Badan', 'Cm', 2, NULL, NULL),
(169, 28, NULL, 'Berat Badan', 'Kg', 2, NULL, NULL),
(170, 29, NULL, 'SISTOLIK', '/', 2, NULL, NULL),
(171, 29, NULL, 'DIASTOLIK', 'mmHg', 2, NULL, NULL),
(173, 3, NULL, 'asdasd', NULL, 4, NULL, NULL),
(174, 4, NULL, 'Lampiran', NULL, 4, NULL, NULL),
(175, 22, NULL, 'DARAH LENGKAP', NULL, 3, NULL, NULL),
(176, 22, 175, 'HITUNG JENIS', NULL, 3, NULL, NULL),
(180, 2, NULL, 'Dokter Pemeriksa', NULL, 5, NULL, ''),
(181, 2, NULL, 'Nama Pemeriksa', NULL, 6, NULL, ''),
(182, 1, NULL, 'Dokter Pemeriksa', NULL, 5, NULL, ''),
(183, 22, NULL, 'Hasil Hematologi', NULL, 7, NULL, ''),
(185, 24, NULL, 'Hasil Kimia', NULL, 7, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_rincian_hasil`
--

CREATE TABLE `pemeriksaan_rincian_hasil` (
  `id` int(11) NOT NULL,
  `id_registrasi` int(11) NOT NULL,
  `id_pemeriksaan_rincian` int(11) NOT NULL,
  `jawaban` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_rincian_hasil`
--

INSERT INTO `pemeriksaan_rincian_hasil` (`id`, `id_registrasi`, `id_pemeriksaan_rincian`, `jawaban`) VALUES
(1, 1, 1, 'Tidak Ada'),
(2, 1, 2, 'Tidak Ada'),
(3, 1, 3, 'Tidak Ada'),
(4, 1, 4, 'Ada'),
(5, 1, 5, 'Tidak Ada'),
(6, 1, 168, '170'),
(7, 1, 169, '200'),
(8, 1, 170, '150'),
(9, 1, 171, '79'),
(10, 1, 65, '1'),
(11, 1, 66, '2'),
(12, 1, 68, '3'),
(13, 1, 69, '4'),
(14, 1, 70, '5'),
(15, 1, 71, '6'),
(16, 1, 72, '7'),
(17, 1, 73, '8'),
(18, 1, 74, '9'),
(19, 1, 75, '10'),
(20, 1, 76, '11'),
(21, 1, 77, '12'),
(22, 1, 85, '1'),
(23, 1, 86, '2'),
(24, 1, 87, '3'),
(25, 1, 88, '4'),
(26, 1, 89, '5'),
(27, 1, 90, '6'),
(28, 1, 92, '7'),
(29, 1, 93, '8'),
(30, 1, 94, '9'),
(31, 1, 96, '1'),
(32, 1, 97, '2'),
(33, 1, 98, 'Negatif'),
(34, 1, 99, 'Negatif'),
(35, 1, 100, 'Negatif'),
(36, 1, 101, 'Positif'),
(37, 1, 103, 'Negatif'),
(38, 1, 104, 'Negatif'),
(39, 1, 105, 'Negatif'),
(40, 1, 107, '1'),
(41, 1, 108, '2'),
(42, 1, 109, 'Negatif'),
(43, 1, 110, 'Positif'),
(44, 1, 111, 'Negatif'),
(45, 1, 112, 'Negatif'),
(46, 1, 119, 'Normal'),
(47, 1, 120, 'Normal'),
(48, 1, 121, 'Normal'),
(49, 1, 122, 'Normal'),
(50, 1, 123, 'Normal'),
(51, 1, 14, 'Pakai'),
(52, 1, 18, 'Normal'),
(53, 1, 22, 'Normal'),
(54, 1, 23, 'Normal'),
(55, 1, 24, 'Isokor'),
(56, 1, 25, 'Normal'),
(57, 1, 26, 'Normal'),
(58, 1, 27, 'Normal'),
(59, 1, 28, 'Normal'),
(60, 1, 29, 'Normal'),
(61, 1, 31, 'Normal'),
(62, 1, 32, '8/7.5 (ODS)'),
(63, 1, 33, 'Normal'),
(64, 1, 34, 'Normal'),
(65, 1, 35, '-/-'),
(66, 1, 36, 'Normal'),
(67, 1, 37, 'Normal'),
(68, 1, 38, 'Ada'),
(69, 1, 39, 'Normal'),
(70, 1, 40, 'Tidak Teraba'),
(71, 1, 41, 'Tidak Teraba'),
(72, 1, 43, 'Normal'),
(73, 1, 44, 'Normal'),
(74, 1, 45, 'Normal'),
(75, 1, 46, 'Normal'),
(76, 1, 47, 'Tidak ada Kelainan'),
(77, 1, 48, 'Normal'),
(78, 1, 49, 'Simetris'),
(79, 1, 50, 'Vesikuler'),
(80, 1, 51, 'Normal'),
(81, 1, 52, 'Normal'),
(82, 1, 53, 'Normal'),
(83, 1, 54, 'Normal'),
(84, 1, 55, 'Normal'),
(85, 1, 56, 'Normal'),
(86, 1, 57, 'Negativ'),
(87, 1, 59, 'Normal'),
(88, 1, 60, 'Normal'),
(89, 1, 61, 'Normal'),
(90, 1, 62, 'Normal'),
(91, 1, 63, 'Normal'),
(92, 1, 64, 'Normal'),
(93, 1, 78, 'Non Reaktif'),
(94, 1, 113, 'Negatif'),
(95, 1, 114, 'Negatif'),
(96, 1, 115, 'Negatif'),
(97, 1, 116, 'Negatif'),
(98, 1, 117, 'Negatif'),
(99, 2, 1, 'Tidak Ada'),
(100, 2, 2, 'Tidak Ada'),
(101, 2, 3, 'Tidak Ada'),
(102, 2, 4, 'Tidak Ada'),
(103, 2, 5, 'Tidak Ada'),
(104, 2, 168, ''),
(105, 2, 169, ''),
(106, 2, 170, ''),
(107, 2, 171, ''),
(108, 2, 65, '90'),
(109, 2, 66, '90'),
(110, 2, 68, '9'),
(111, 2, 69, '09'),
(112, 2, 70, '090'),
(113, 2, 71, ''),
(114, 2, 72, ''),
(115, 2, 73, ''),
(116, 2, 74, ''),
(117, 2, 75, ''),
(118, 2, 76, ''),
(119, 2, 77, ''),
(120, 2, 85, ''),
(121, 2, 86, ''),
(122, 2, 87, ''),
(123, 2, 88, ''),
(124, 2, 89, ''),
(125, 2, 90, ''),
(126, 2, 92, ''),
(127, 2, 93, ''),
(128, 2, 94, ''),
(129, 2, 96, ''),
(130, 2, 97, ''),
(131, 2, 98, 'Negatif'),
(132, 2, 99, 'Negatif'),
(133, 2, 100, 'Negatif'),
(134, 2, 101, 'Positif'),
(135, 2, 103, 'Negatif'),
(136, 2, 104, 'Negatif'),
(137, 2, 105, 'Negatif'),
(138, 2, 107, ''),
(139, 2, 108, ''),
(140, 2, 109, 'Negatif'),
(141, 2, 110, 'Positif'),
(142, 2, 111, 'Negatif'),
(143, 2, 112, 'Negatif'),
(144, 2, 119, 'Normal'),
(145, 2, 120, 'Normal'),
(146, 2, 121, 'Normal'),
(147, 2, 122, 'Normal'),
(148, 2, 123, 'Normal'),
(149, 1, 124, 'Normal'),
(150, 1, 125, 'Normal'),
(151, 1, 126, ''),
(152, 1, 127, ''),
(153, 1, 128, ''),
(154, 1, 129, ''),
(155, 1, 130, ''),
(156, 1, 131, ''),
(157, 1, 132, ''),
(158, 1, 133, ''),
(159, 2, 124, 'Normal'),
(160, 2, 125, 'Normal'),
(161, 2, 126, ''),
(162, 2, 127, ''),
(163, 2, 128, ''),
(164, 2, 129, ''),
(165, 2, 130, ''),
(166, 2, 131, ''),
(167, 2, 132, ''),
(168, 2, 133, ''),
(169, 2, 64, 'Abnormal'),
(170, 2, 180, '6'),
(171, 1, 180, '6'),
(172, 1, 181, 'dadan 123'),
(173, 2, 182, ''),
(174, 2, 181, '1'),
(175, 2, 14, 'Tidak Pakai'),
(176, 2, 183, 'Normal'),
(177, 2, 185, 'Tidak Normal');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_rincian_pilihan`
--

CREATE TABLE `pemeriksaan_rincian_pilihan` (
  `id` int(11) NOT NULL,
  `id_pemeriksaan_rincian` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `default_value` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_rincian_pilihan`
--

INSERT INTO `pemeriksaan_rincian_pilihan` (`id`, `id_pemeriksaan_rincian`, `nama`, `default_value`) VALUES
(1, 14, 'Pakai', NULL),
(2, 14, 'Tidak Pakai', NULL),
(3, 18, 'Normal', NULL),
(4, 18, 'Hordeolum', NULL),
(5, 18, 'Lain-Lain', NULL),
(7, 22, 'Normal', NULL),
(8, 22, 'Anemis', NULL),
(9, 22, 'Lain-Lain', NULL),
(10, 23, 'Normal', NULL),
(11, 23, 'Icteric', NULL),
(12, 23, 'Lain-Lain', NULL),
(13, 24, 'Isokor', NULL),
(14, 24, 'Lain-Lain', NULL),
(15, 25, 'Normal', NULL),
(16, 25, 'Parsial', NULL),
(17, 25, 'Total', NULL),
(18, 26, 'Normal', NULL),
(19, 26, 'Tidak Normal', NULL),
(20, 27, 'Normal', NULL),
(21, 27, 'Tidak Normal', NULL),
(22, 28, 'Normal', NULL),
(23, 28, 'Tidak Normal', NULL),
(24, 29, 'Normal', NULL),
(25, 29, 'Tidak Normal', NULL),
(26, 31, 'Normal', NULL),
(27, 31, 'Juling Kanan', NULL),
(28, 31, 'Juling Kiri', NULL),
(29, 32, '8/7.5 (ODS)', NULL),
(30, 32, 'Tidak Normal', NULL),
(31, 33, 'Normal', NULL),
(32, 33, 'Lain-Lain', NULL),
(33, 34, 'Normal', NULL),
(34, 34, 'Tidak Normal', NULL),
(35, 35, '-/-', NULL),
(36, 35, '-/+', NULL),
(37, 35, '+/-', NULL),
(38, 35, '+/+', NULL),
(39, 36, 'Normal', NULL),
(40, 36, 'Lain-Lain', NULL),
(41, 37, 'Normal', NULL),
(42, 37, 'Lain-Lain', NULL),
(43, 38, 'Ada', NULL),
(44, 38, 'Tidak Ada', NULL),
(45, 39, 'Normal', NULL),
(46, 39, 'Tidak Normal', NULL),
(47, 40, 'Tidak Teraba', NULL),
(48, 40, 'Membesar', NULL),
(49, 41, 'Tidak Teraba', NULL),
(50, 41, 'Membesar', NULL),
(51, 43, 'Normal', NULL),
(52, 43, 'Hiperemis', NULL),
(53, 43, 'Pembesaran Tonsil', NULL),
(54, 44, 'Normal', NULL),
(55, 44, 'Pembesaran Tonsil', NULL),
(56, 45, 'Normal', NULL),
(57, 45, 'Hiperemis', NULL),
(58, 46, 'Normal', NULL),
(59, 46, 'Stomatitis', NULL),
(60, 46, 'Lain-Lain', NULL),
(61, 47, 'Tidak ada Kelainan', NULL),
(62, 47, 'Caries', NULL),
(63, 47, 'Tambal', NULL),
(64, 47, 'Calkulus', NULL),
(65, 48, 'Normal', NULL),
(66, 48, 'Tidak Normal', NULL),
(67, 49, 'Simetris', NULL),
(68, 49, 'Asimetris', NULL),
(69, 50, 'Vesikuler', NULL),
(70, 50, 'Slam', NULL),
(71, 50, 'Wheezing', NULL),
(72, 50, 'Ronkhi', NULL),
(73, 50, 'Lain-Lain', NULL),
(74, 51, 'Normal', NULL),
(75, 51, 'Mur-mur', NULL),
(76, 51, 'Extrasistole', NULL),
(77, 51, 'Galloy', NULL),
(78, 52, 'Normal', NULL),
(79, 52, 'Nyeri Tekan Epigastrum', NULL),
(80, 52, 'Lain-Lain', NULL),
(81, 53, 'Normal', NULL),
(82, 53, 'Hati Teraba', NULL),
(83, 53, 'Lain-Lain', NULL),
(84, 54, 'Normal', NULL),
(85, 54, 'Limpa Membesar', NULL),
(86, 54, 'Lain-Lain', NULL),
(87, 55, 'Normal', NULL),
(88, 55, 'Nyeri Ketok CVA', NULL),
(89, 55, 'Lain-Lain', NULL),
(90, 56, 'Normal', NULL),
(91, 56, 'Tidak Normal', NULL),
(92, 57, 'Negativ', NULL),
(93, 57, 'Positif', NULL),
(94, 59, 'Normal', NULL),
(95, 59, 'Paralisis', NULL),
(96, 59, 'Palese', NULL),
(97, 59, 'Lain-Lain', NULL),
(98, 60, 'Normal', NULL),
(99, 60, 'Tidak Normal', NULL),
(100, 60, 'Lain-Lain', NULL),
(101, 61, 'Normal', NULL),
(102, 61, 'Tidak Normal', NULL),
(103, 62, 'Normal', NULL),
(104, 62, 'Tidak Normal', NULL),
(105, 63, 'Normal', NULL),
(106, 63, 'Tidak Normal', NULL),
(107, 64, 'Normal', NULL),
(108, 64, 'Dalam Batas Normal', NULL),
(109, 64, 'Abnormal', NULL),
(110, 78, 'Reaktif', NULL),
(111, 78, 'Non Reaktif', NULL),
(112, 113, 'Negatif', NULL),
(113, 113, 'Positif', NULL),
(114, 114, 'Negatif', NULL),
(115, 114, 'Positif', NULL),
(116, 115, 'Negatif', NULL),
(117, 115, 'Positif', NULL),
(118, 116, 'Negatif', NULL),
(119, 116, 'Positif', NULL),
(120, 117, 'Negatif', NULL),
(121, 117, 'Positif', NULL),
(122, 137, 'Normal', NULL),
(123, 137, 'Membesar', NULL),
(124, 147, 'Negatif', NULL),
(125, 147, '+ Ringan', NULL),
(126, 147, '+ Sedang', NULL),
(127, 147, '+ Parah', NULL),
(128, 183, 'Normal', NULL),
(129, 183, 'Tidak Normal', NULL),
(131, 185, 'Normal', NULL),
(132, 185, 'Tidak Normal', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_spirometry`
--

CREATE TABLE `pemeriksaan_spirometry` (
  `id` int(11) NOT NULL,
  `id_registrasi` int(11) NOT NULL,
  `hasil` varchar(255) DEFAULT 'Normal',
  `kesimpulan` varchar(255) DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_spirometry`
--

INSERT INTO `pemeriksaan_spirometry` (`id`, `id_registrasi`, `hasil`, `kesimpulan`) VALUES
(2, 35, 'Normal', 'Normal'),
(3, 1, 'Normal', 'Normal'),
(4, 2, 'Normal', 'Normal'),
(5, 3, 'Normal', 'Normal'),
(6, 4, 'Normal', 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_treadmill`
--

CREATE TABLE `pemeriksaan_treadmill` (
  `id` int(11) NOT NULL,
  `id_registrasi` int(11) NOT NULL,
  `metode` varchar(255) DEFAULT NULL,
  `jantung` varchar(255) DEFAULT NULL,
  `kf_poor` varchar(11) DEFAULT NULL,
  `kf_fair` varchar(11) DEFAULT NULL,
  `kf_average` varchar(11) DEFAULT NULL,
  `kf_good` varchar(11) DEFAULT NULL,
  `kf_excelent` varchar(11) DEFAULT NULL,
  `klasifikasi_fungsional_1` varchar(11) DEFAULT NULL,
  `klasifikasi_fungsional_2` varchar(11) DEFAULT NULL,
  `klasifikasi_fungsional_3` varchar(11) DEFAULT NULL,
  `denyut_nadi_awal` varchar(11) DEFAULT NULL,
  `denyut_nadi_akhir` varchar(11) DEFAULT NULL,
  `td_sistolik_awal` int(11) DEFAULT NULL,
  `td_diastolik_awal` int(11) DEFAULT NULL,
  `td_sistolik_akhir` int(11) DEFAULT NULL,
  `td_diastolik_akhir` int(11) DEFAULT NULL,
  `stop_treadmill` varchar(255) DEFAULT NULL,
  `resume_hasil` varchar(255) DEFAULT 'Abnormal',
  `max` varchar(11) DEFAULT NULL,
  `submax` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_treadmill`
--

INSERT INTO `pemeriksaan_treadmill` (`id`, `id_registrasi`, `metode`, `jantung`, `kf_poor`, `kf_fair`, `kf_average`, `kf_good`, `kf_excelent`, `klasifikasi_fungsional_1`, `klasifikasi_fungsional_2`, `klasifikasi_fungsional_3`, `denyut_nadi_awal`, `denyut_nadi_akhir`, `td_sistolik_awal`, `td_diastolik_awal`, `td_sistolik_akhir`, `td_diastolik_akhir`, `stop_treadmill`, `resume_hasil`, `max`, `submax`) VALUES
(2, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Abnormal', NULL, NULL),
(3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Abnormal', NULL, NULL),
(4, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Abnormal', NULL, NULL),
(5, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Abnormal', NULL, NULL),
(6, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Abnormal', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_treadmill_anjuran`
--

CREATE TABLE `pemeriksaan_treadmill_anjuran` (
  `id` int(11) NOT NULL,
  `id_pemeriksaan_treadmill` int(11) NOT NULL,
  `jalan` varchar(11) DEFAULT NULL,
  `denyut_nadi` varchar(11) DEFAULT NULL,
  `frekuensi` varchar(11) DEFAULT NULL,
  `olahraga_lain` varchar(11) DEFAULT NULL,
  `konsultasi_kardiologi` varchar(11) DEFAULT NULL,
  `treadmill_ulang` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan_usg`
--

CREATE TABLE `pemeriksaan_usg` (
  `id` int(11) NOT NULL,
  `id_registrasi` int(11) NOT NULL,
  `hati` varchar(255) DEFAULT NULL,
  `kgb` varchar(255) DEFAULT NULL,
  `empedu` varchar(255) DEFAULT NULL,
  `limpa` varchar(255) DEFAULT NULL,
  `pankreas` varchar(255) DEFAULT NULL,
  `ginjal` varchar(255) DEFAULT NULL,
  `kemih` varchar(255) DEFAULT NULL,
  `lainlain` varchar(255) DEFAULT NULL,
  `kesimpulan` varchar(255) DEFAULT 'Abnormal'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan_usg`
--

INSERT INTO `pemeriksaan_usg` (`id`, `id_registrasi`, `hati`, `kgb`, `empedu`, `limpa`, `pankreas`, `ginjal`, `kemih`, `lainlain`, `kesimpulan`) VALUES
(2, 35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Abnormal'),
(3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Abnormal'),
(4, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Abnormal'),
(5, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Abnormal'),
(6, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Abnormal');

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan`
--

CREATE TABLE `pendidikan` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pendidikan`
--

INSERT INTO `pendidikan` (`id`, `nama`) VALUES
(1, 'SD'),
(2, 'SMP'),
(3, 'SLTA'),
(4, 'DIPLOMA'),
(5, 'SARJANA'),
(6, 'S2'),
(7, 'S3'),
(8, 'Lain-Lain'),
(9, 'Tidak Sekolah');

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`id`, `nama`) VALUES
(1, 'Agus');

-- --------------------------------------------------------

--
-- Table structure for table `radiologi`
--

CREATE TABLE `radiologi` (
  `id` int(11) NOT NULL,
  `id_registrasi` int(11) NOT NULL,
  `hasil_pemeriksaan` varchar(255) DEFAULT 'Normal',
  `cor` varchar(255) DEFAULT 'Normal',
  `pulmo` varchar(255) DEFAULT 'Normal',
  `sinus_diafragma` varchar(255) DEFAULT 'Normal',
  `tulang_jaringan_lunak` varchar(255) DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `radiologi`
--

INSERT INTO `radiologi` (`id`, `id_registrasi`, `hasil_pemeriksaan`, `cor`, `pulmo`, `sinus_diafragma`, `tulang_jaringan_lunak`) VALUES
(2, 35, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal'),
(3, 1, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal'),
(4, 2, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal'),
(5, 3, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal'),
(6, 4, 'Normal', 'Normal', 'Normal', 'Normal', 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `registrasi`
--

CREATE TABLE `registrasi` (
  `id` int(11) NOT NULL,
  `no_registrasi` int(11) NOT NULL,
  `no_mcu` varchar(11) NOT NULL,
  `no_urut` int(11) NOT NULL,
  `paket_id` int(11) NOT NULL,
  `pasien_id` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `nik_pasien` varchar(255) DEFAULT NULL,
  `nama_pasien` varchar(255) DEFAULT NULL,
  `alamat_pasien` varchar(255) DEFAULT NULL,
  `tempat_lahir_pasien` varchar(255) DEFAULT NULL,
  `tanggal_lahir_pasien` date DEFAULT NULL,
  `jenis_kelamin_pasien` varchar(10) DEFAULT NULL,
  `golongan_darah_pasien` varchar(10) DEFAULT NULL,
  `no_telepon_pasien` varchar(20) DEFAULT NULL,
  `status_kawin_pasien` varchar(255) DEFAULT NULL,
  `id_pasien_instansi` int(11) DEFAULT NULL,
  `id_pasien_unit` int(11) DEFAULT NULL,
  `id_pasien_agama` int(11) DEFAULT NULL,
  `id_pasien_pekerjaan` int(11) DEFAULT NULL,
  `id_pasien_pendidikan` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrasi`
--

INSERT INTO `registrasi` (`id`, `no_registrasi`, `no_mcu`, `no_urut`, `paket_id`, `pasien_id`, `tanggal`, `nik_pasien`, `nama_pasien`, `alamat_pasien`, `tempat_lahir_pasien`, `tanggal_lahir_pasien`, `jenis_kelamin_pasien`, `golongan_darah_pasien`, `no_telepon_pasien`, `status_kawin_pasien`, `id_pasien_instansi`, `id_pasien_unit`, `id_pasien_agama`, `id_pasien_pekerjaan`, `id_pasien_pendidikan`) VALUES
(1, 1, '11110001', 1, 1, 1, '2019-01-08', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 2, '11110002', 2, 1, 3, '2019-01-08', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 1, '06180001', 1, 2, 4, '2019-01-01', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tindakan`
--

CREATE TABLE `tindakan` (
  `id` int(11) NOT NULL,
  `kode` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tindakan`
--

INSERT INTO `tindakan` (`id`, `kode`, `nama`) VALUES
(1, 'LTes', '01'),
(2, 'LB-0000074', 'H2TL');

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `id` int(11) NOT NULL,
  `instansi_id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`id`, `instansi_id`, `nama`) VALUES
(3, 3, 'Unit Pengembangan'),
(4, 4, 'SIMRS'),
(5, 4, 'PENDAFTARAN');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `auth_key` varchar(255) DEFAULT NULL,
  `id_user_role` int(11) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `id_instansi` int(11) DEFAULT NULL,
  `id_dokter` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `auth_key`, `id_user_role`, `email`, `id_instansi`, `id_dokter`) VALUES
(1, 'admin', '$2y$13$hqWekYoFqDInOk6fWaTpeONetrIxrc5Tb1kK5TumqGVMbLDI30HRK', NULL, 1, NULL, NULL, NULL),
(3, 'instansi', '$2y$13$IL88PEQF1LOxOP6b0dwWNulDMS2SKGjjmDC3UpM0Be5fMZEPmQo0S', NULL, 2, 'tes@gmail.com', 8, NULL),
(4, 'dokter', '$2y$13$lDrLyjqWOLSdkP70OikMx.hz0djFjf8gDM6qzITByUHNS6ZctRRmK', NULL, 3, 'dokter@gmail.com', NULL, 6);

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`id`, `nama`) VALUES
(1, 'admin'),
(2, 'instansi'),
(3, 'dokter');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agama`
--
ALTER TABLE `agama`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `diagnosa_kerja`
--
ALTER TABLE `diagnosa_kerja`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dokter`
--
ALTER TABLE `dokter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instansi`
--
ALTER TABLE `instansi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kesimpulan`
--
ALTER TABLE `kesimpulan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kop`
--
ALTER TABLE `kop`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `laboratorium`
--
ALTER TABLE `laboratorium`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `laboratorium_hematologi`
--
ALTER TABLE `laboratorium_hematologi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `laboratorium_imunoserologi`
--
ALTER TABLE `laboratorium_imunoserologi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `laboratorium_kimia`
--
ALTER TABLE `laboratorium_kimia`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `laboratorium_narkoba`
--
ALTER TABLE `laboratorium_narkoba`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `laboratorium_urinalisa`
--
ALTER TABLE `laboratorium_urinalisa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paket`
--
ALTER TABLE `paket`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paket_pemeriksaan`
--
ALTER TABLE `paket_pemeriksaan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paket_tindakan`
--
ALTER TABLE `paket_tindakan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pekerjaan`
--
ALTER TABLE `pekerjaan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan`
--
ALTER TABLE `pemeriksaan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_audiometry`
--
ALTER TABLE `pemeriksaan_audiometry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_ekg`
--
ALTER TABLE `pemeriksaan_ekg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_fisik`
--
ALTER TABLE `pemeriksaan_fisik`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_fisik_abdomen`
--
ALTER TABLE `pemeriksaan_fisik_abdomen`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_fisik_hidung`
--
ALTER TABLE `pemeriksaan_fisik_hidung`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_fisik_leher`
--
ALTER TABLE `pemeriksaan_fisik_leher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_fisik_manufer_ekstremitas`
--
ALTER TABLE `pemeriksaan_fisik_manufer_ekstremitas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_fisik_mata`
--
ALTER TABLE `pemeriksaan_fisik_mata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_fisik_mulut`
--
ALTER TABLE `pemeriksaan_fisik_mulut`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_fisik_telinga`
--
ALTER TABLE `pemeriksaan_fisik_telinga`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_fisik_thorax`
--
ALTER TABLE `pemeriksaan_fisik_thorax`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_fisik_timpani`
--
ALTER TABLE `pemeriksaan_fisik_timpani`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_rincian`
--
ALTER TABLE `pemeriksaan_rincian`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_rincian_hasil`
--
ALTER TABLE `pemeriksaan_rincian_hasil`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_rincian_pilihan`
--
ALTER TABLE `pemeriksaan_rincian_pilihan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_spirometry`
--
ALTER TABLE `pemeriksaan_spirometry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_treadmill`
--
ALTER TABLE `pemeriksaan_treadmill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_treadmill_anjuran`
--
ALTER TABLE `pemeriksaan_treadmill_anjuran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemeriksaan_usg`
--
ALTER TABLE `pemeriksaan_usg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pendidikan`
--
ALTER TABLE `pendidikan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `radiologi`
--
ALTER TABLE `radiologi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registrasi`
--
ALTER TABLE `registrasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tindakan`
--
ALTER TABLE `tindakan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agama`
--
ALTER TABLE `agama`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `diagnosa_kerja`
--
ALTER TABLE `diagnosa_kerja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `dokter`
--
ALTER TABLE `dokter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `instansi`
--
ALTER TABLE `instansi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `kesimpulan`
--
ALTER TABLE `kesimpulan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `kop`
--
ALTER TABLE `kop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `laboratorium`
--
ALTER TABLE `laboratorium`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `laboratorium_hematologi`
--
ALTER TABLE `laboratorium_hematologi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `laboratorium_imunoserologi`
--
ALTER TABLE `laboratorium_imunoserologi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `laboratorium_kimia`
--
ALTER TABLE `laboratorium_kimia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `laboratorium_narkoba`
--
ALTER TABLE `laboratorium_narkoba`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `laboratorium_urinalisa`
--
ALTER TABLE `laboratorium_urinalisa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `paket`
--
ALTER TABLE `paket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `paket_pemeriksaan`
--
ALTER TABLE `paket_pemeriksaan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `paket_tindakan`
--
ALTER TABLE `paket_tindakan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pasien`
--
ALTER TABLE `pasien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `pekerjaan`
--
ALTER TABLE `pekerjaan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pemeriksaan`
--
ALTER TABLE `pemeriksaan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `pemeriksaan_audiometry`
--
ALTER TABLE `pemeriksaan_audiometry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `pemeriksaan_ekg`
--
ALTER TABLE `pemeriksaan_ekg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `pemeriksaan_fisik`
--
ALTER TABLE `pemeriksaan_fisik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `pemeriksaan_fisik_abdomen`
--
ALTER TABLE `pemeriksaan_fisik_abdomen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pemeriksaan_fisik_hidung`
--
ALTER TABLE `pemeriksaan_fisik_hidung`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pemeriksaan_fisik_leher`
--
ALTER TABLE `pemeriksaan_fisik_leher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pemeriksaan_fisik_manufer_ekstremitas`
--
ALTER TABLE `pemeriksaan_fisik_manufer_ekstremitas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pemeriksaan_fisik_mata`
--
ALTER TABLE `pemeriksaan_fisik_mata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pemeriksaan_fisik_mulut`
--
ALTER TABLE `pemeriksaan_fisik_mulut`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pemeriksaan_fisik_telinga`
--
ALTER TABLE `pemeriksaan_fisik_telinga`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pemeriksaan_fisik_thorax`
--
ALTER TABLE `pemeriksaan_fisik_thorax`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pemeriksaan_fisik_timpani`
--
ALTER TABLE `pemeriksaan_fisik_timpani`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pemeriksaan_rincian`
--
ALTER TABLE `pemeriksaan_rincian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=186;
--
-- AUTO_INCREMENT for table `pemeriksaan_rincian_hasil`
--
ALTER TABLE `pemeriksaan_rincian_hasil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=178;
--
-- AUTO_INCREMENT for table `pemeriksaan_rincian_pilihan`
--
ALTER TABLE `pemeriksaan_rincian_pilihan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;
--
-- AUTO_INCREMENT for table `pemeriksaan_spirometry`
--
ALTER TABLE `pemeriksaan_spirometry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `pemeriksaan_treadmill`
--
ALTER TABLE `pemeriksaan_treadmill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `pemeriksaan_treadmill_anjuran`
--
ALTER TABLE `pemeriksaan_treadmill_anjuran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pemeriksaan_usg`
--
ALTER TABLE `pemeriksaan_usg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `pendidikan`
--
ALTER TABLE `pendidikan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `petugas`
--
ALTER TABLE `petugas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `radiologi`
--
ALTER TABLE `radiologi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `registrasi`
--
ALTER TABLE `registrasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tindakan`
--
ALTER TABLE `tindakan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
